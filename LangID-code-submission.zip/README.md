# Sinhala-script language identification

This branch contains two components: a reproducible research data pipeline and the full-stack language-identification web app.

## Research pipeline

The eight-stage workflow lives in [`data_pipeline/`](data_pipeline/). It downloads pinned benchmark inputs, prepares and audits the target and rehearsal datasets, trains baselines and multilingual models, evaluates them, and generates result tables from per-example predictions.

```bash
cd data_pipeline
uv sync
uv run python run_pipeline.py --preflight-only
uv run python run_pipeline.py
```

Read [`data_pipeline/README.md`](data_pipeline/README.md) before running. The full run needs access to gated datasets, large model downloads, substantial disk space, and potentially a GPU. The three original target-corpus CSVs required to rebuild its published target split are in `data_pipeline/source_data/target/`. The latest externally supplied three-regime result sheet is retained in `data_pipeline/reference/` for comparison; it is not evidence that this checkout has completed a full run.

## Web application

The production application is in [`webapp/`](webapp/): FastAPI/Celery backend, Next.js frontend, Docker Compose deployment, and tests. It serves the included small baseline model and can serve stage-07 rehearsal checkpoints after they have been generated or copied to the configured model directory.

```bash
cd webapp
cp .env.example .env
# Set the required domain and secrets in .env.
docker compose up -d --build
```

See [`webapp/README.md`](webapp/README.md) for local development, model paths, deployment, and resource requirements. Research manuscripts and historical experiments are maintained on other branches, not in this streamlined branch.
