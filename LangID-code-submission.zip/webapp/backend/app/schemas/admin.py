from pydantic import BaseModel, ConfigDict
from typing import Optional, List
from uuid import UUID

from app.db.models.model_rate import ModelType

class TierBase(BaseModel):
    name: str
    price_usd: float
    included_credits: float
    ocr_pages_included: int

class TierCreate(TierBase):
    pass

class TierUpdate(BaseModel):
    name: Optional[str] = None
    price_usd: Optional[float] = None
    included_credits: Optional[float] = None
    ocr_pages_included: Optional[int] = None
    is_active: Optional[bool] = None

class TierResponse(TierBase):
    id: UUID
    is_active: bool
    model_config = ConfigDict(from_attributes=True)

class CreditPackageConfig(BaseModel):
    id: str
    name: str
    credits: float
    amount_lkr: float
    popular: bool = False
    description: str

class SystemConfigBase(BaseModel):
    usd_to_credits_rate: float
    usd_to_lkr_rate: Optional[float] = 300.0
    packages: Optional[List[CreditPackageConfig]] = None

class SystemConfigUpdate(BaseModel):
    usd_to_credits_rate: float
    usd_to_lkr_rate: Optional[float] = 300.0
    packages: Optional[List[CreditPackageConfig]] = None

class SystemConfigResponse(SystemConfigBase):
    pass

class ModelRateBase(BaseModel):
    model_type: ModelType
    model_name: str
    credits_per_token: Optional[float] = 0.0
    credits_per_page: Optional[float] = 0.0

class ModelRateCreate(ModelRateBase):
    pass

class ModelRateUpdate(BaseModel):
    credits_per_token: Optional[float] = None
    credits_per_page: Optional[float] = None

class ModelRateResponse(ModelRateBase):
    id: UUID
    is_active: bool
    model_config = ConfigDict(from_attributes=True)

class AdminStatsResponse(BaseModel):
    total_users: int
    active_subscriptions: int
    storage_used_bytes: int
    active_jobs: int
