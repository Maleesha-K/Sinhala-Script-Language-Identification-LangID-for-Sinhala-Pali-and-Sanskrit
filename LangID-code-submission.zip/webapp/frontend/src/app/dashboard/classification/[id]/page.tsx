"use client";

import { useState, useEffect, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import { toast } from "sonner";
import { ArrowLeft, Loader2, CheckCircle2, XCircle, Clock, Zap, Download, Ban, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/auth-context";
import { apiErrorDetail, cn } from "@/lib/utils";
import { useLiveChannel, type LiveEvent } from "@/lib/live";
import {
  DEFAULT_CORRECTION_LANGUAGES, LanguageSummary, SegmentText, mergeSegments, type Segment,
} from "@/components/classification/segments";
import { languageLabel } from "@/lib/language-colors";
import { downloadCsv } from "@/lib/export";

type JobStatus = "queued" | "processing" | "completed" | "failed" | "cancelled";

type JobData = {
  id: string;
  status: JobStatus;
  model_name?: string;
  segmentation_strategy: string;
  total_tokens: number;
  error_message?: string | null;
  cancel_requested?: boolean;
  input_text?: string | null;
  done?: number | null;
  total?: number | null;
  segments: Segment[];
};

export default function ClassificationResultPage() {
  const params = useParams();
  const router = useRouter();
  const { refreshUser } = useAuth();
  const [job, setJob] = useState<JobData | null>(null);
  const [correctionLanguages, setCorrectionLanguages] = useState<string[]>(DEFAULT_CORRECTION_LANGUAGES);
  const [modelLabel, setModelLabel] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [focus, setFocus] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);

  const fetchJob = useCallback(async () => {
    try {
      const res = await axios.get(`/api/classification/jobs/${params.id}`);
      const data = res.data.data;
      setJob({ ...data, segments: data.segments ?? [] });
    } catch (error) {
      toast.error(apiErrorDetail(error, "Failed to load job results"));
    } finally {
      setLoading(false);
    }
  }, [params.id]);

  // Load once; while the job runs, the live channel reloads and streams.
  useEffect(() => {
    fetchJob();
  }, [fetchJob]);

  const isRunning = job?.status === "queued" || job?.status === "processing";

  useLiveChannel({
    path: `/ws/jobs/${params.id}`,
    enabled: isRunning,
    load: fetchJob,
    onEvent: (event: LiveEvent) => {
      setJob((prev) => {
        if (!prev) return prev;
        if (event.type === "segments") {
          return {
            ...prev,
            segments: mergeSegments(prev.segments, event.segments as Segment[]),
            done: event.done as number,
            total: event.total as number,
          };
        }
        if (event.type === "status") {
          return {
            ...prev,
            status: event.status as JobStatus,
            cancel_requested: (event.cancel_requested as boolean | undefined) ?? prev.cancel_requested,
            done: (event.done as number | undefined) ?? prev.done,
            total: (event.total as number | undefined) ?? prev.total,
            error_message: event.status === "failed" ? (event.message as string) || prev.error_message : prev.error_message,
          };
        }
        return prev;
      });
    },
    isFinal: (event) =>
      event.type === "status" && ["completed", "failed", "cancelled"].includes(event.status as string),
  });

  // The job is charged when it starts (and partly refunded when cancelled),
  // so refresh the balance in the header.
  useEffect(() => {
    if (job?.status === "processing" || job?.status === "completed" || job?.status === "cancelled") refreshUser();
  }, [job?.status, refreshUser]);

  const handleCancel = async () => {
    if (!confirm("Stop this classification? Sentences classified so far are kept, and you are refunded for the rest.")) return;
    setCancelling(true);
    try {
      const res = await axios.post(`/api/classification/jobs/${params.id}/cancel`);
      const { status, cancel_requested } = res.data.data;
      setJob((prev) => (prev ? { ...prev, status, cancel_requested } : prev));
      toast.success(res.data.message);
    } catch (error) {
      toast.error(apiErrorDetail(error, "Failed to cancel the job"));
      fetchJob();
    } finally {
      setCancelling(false);
    }
  };

  // The correction options depend on the model that produced this job: the
  // baseline is three-way, the fine-tuned checkpoints also know the replay
  // languages.
  useEffect(() => {
    if (!job?.model_name) return;
    let cancelled = false;
    axios
      .get("/api/classification/models")
      .then((res) => {
        if (cancelled) return;
        const match = (res.data?.data ?? []).find((m: { id: string }) => m.id === job.model_name);
        if (match?.label) setModelLabel(match.label);
        if (match?.correction_languages?.length) {
          setCorrectionLanguages(match.correction_languages);
        }
      })
      .catch(() => {
        /* keep the three-category default */
      });
    return () => {
      cancelled = true;
    };
  }, [job?.model_name]);

  const statusConfig = {
    queued:     { icon: Clock,       color: "text-amber-500",  label: "Queued" },
    processing: { icon: Loader2,     color: "text-primary",    label: "Processing" },
    completed:  { icon: CheckCircle2, color: "text-emerald-500", label: "Completed" },
    failed:     { icon: XCircle,     color: "text-destructive", label: "Failed" },
    cancelled:  { icon: Ban,         color: "text-amber-600",  label: "Cancelled" },
  };

  if (loading && !job) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-3 text-muted-foreground">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-sm">Loading job results…</p>
      </div>
    );
  }

  if (!job) return null;

  const exportCsv = () =>
    downloadCsv(`classification-${job.id.slice(0, 8)}.csv`, [
      ["segment", "language", "confidence", "text"],
      ...job.segments.map((s) => [s.segment_index + 1, languageLabel(s.predicted_language), s.confidence.toFixed(4), s.text.trim()]),
    ]);

  const StatusIcon = statusConfig[job.status]?.icon ?? Clock;
  const statusColor = statusConfig[job.status]?.color ?? "text-muted-foreground";
  const statusLabel = statusConfig[job.status]?.label ?? job.status;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => router.push("/dashboard/classification")} className="gap-2 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
        <div className="flex-1">
          <h1 className="text-xl font-bold tracking-tight">Classification Results</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Model: <span className="font-medium">{modelLabel ?? job.model_name ?? "—"}</span>
            {" · "}Strategy: <span className="font-medium capitalize">{job.segmentation_strategy}</span>
            {job.total_tokens > 0 && (
              <> · <span className="font-medium">{job.total_tokens}</span> tokens</>
            )}
          </p>
        </div>
        <div className={cn("flex items-center gap-1.5 text-sm font-medium", statusColor)}>
          <StatusIcon className={cn("h-4 w-4", job.status === "processing" && "animate-spin")} />
          {statusLabel}
        </div>
        {isRunning && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleCancel}
            disabled={cancelling || job.cancel_requested}
            className="gap-2 text-destructive border-destructive/30 hover:bg-destructive/5 hover:text-destructive"
          >
            {cancelling || job.cancel_requested ? <Loader2 className="h-4 w-4 animate-spin" /> : <Square className="h-3.5 w-3.5 fill-current" />}
            {job.cancel_requested ? "Cancelling…" : "Cancel"}
          </Button>
        )}
        {(job.status === "completed" || job.status === "cancelled") && job.segments.length > 0 && (
          <Button variant="outline" size="sm" onClick={exportCsv} className="gap-2">
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
        )}
      </div>

      {/* Progress, while segments stream in below */}
      {isRunning && (
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Zap className="h-4 w-4 text-primary" />
            {job.cancel_requested
              ? "Cancelling: stopping after the current batch…"
              : job.status === "queued"
              ? "Waiting for a worker…"
              : job.total
                ? `Classified ${job.done ?? 0} of ${job.total} segments`
                : "Segmenting…"}
          </div>
          <div className="h-1.5 bg-primary/20 rounded-full overflow-hidden">
            {job.total ? (
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${Math.round(100 * (job.done ?? 0) / job.total)}%` }}
              />
            ) : (
              <div className="h-full bg-primary rounded-full animate-pulse w-1/3" />
            )}
          </div>
        </div>
      )}

      {/* Cancelled state */}
      {job.status === "cancelled" && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-5 py-4 flex items-start gap-3">
          <Ban className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
          <div className="text-sm">
            <p className="font-medium text-amber-900">Classification cancelled</p>
            <p className="text-xs text-amber-800 mt-0.5">
              {job.segments.length > 0
                ? `${job.segments.length} sentence${job.segments.length === 1 ? " was" : "s were"} classified before you cancelled; they are highlighted below. You were refunded for the rest.`
                : "It was cancelled before any sentence was classified. You were not charged."}
            </p>
          </div>
        </div>
      )}

      {/* Failed state */}
      {job.status === "failed" && (
        <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-center space-y-2">
          <XCircle className="h-8 w-8 text-destructive mx-auto" />
          <p className="font-semibold text-sm">Classification failed</p>
          <p className="text-xs text-muted-foreground">{job.error_message || "An error occurred during processing."}</p>
          {job.segments.length > 0 && (
            <p className="text-xs text-muted-foreground">The segments classified before the failure are shown below. You were not charged.</p>
          )}
        </div>
      )}

      {/* The text as submitted, highlighted as segments arrive */}
      {(job.input_text || job.segments.length > 0) && (
        <div className="space-y-4">
          <LanguageSummary segments={job.segments} focus={focus} onFocus={setFocus} />
          <div className="rounded-xl border border-border bg-white shadow-sm p-6 leading-[2.2] text-base">
            <SegmentText
              text={job.input_text}
              segments={job.segments}
              correctionLanguages={correctionLanguages}
              running={isRunning}
              focus={focus}
            />
          </div>
        </div>
      )}
    </div>
  );
}
